import 'dart:io';
import 'dart:convert';

void main() {
  print('Hello World');
  int id;
  String nome;
  String cidade;
  String estado;
  int idade;

  String? resposta;
  print('informe o seu nome:');
  resposta = stdin.readLineSync()!;
  nome = resposta;
  print('O seu nome é $nome');

  print('informe a sua idade:');
  resposta = stdin.readLineSync();
  if (resposta != null) {
    try {
      idade = int.parse(resposta);
      print('a idade é $idade');
    } catch (e) {
      print('a resposta deve ser número');
    }
  } else {
    print('resposta nula');
  }

  print('informe sua cidade:');
  resposta = stdin.readLineSync();
  if (resposta != null) {
    try {
      String resposta = '{""}';
      var cidade = jsonDecode(resposta);
    } catch (e) {
      print("");
    }
  } else {
    print('resposta nula');
  }
  print('o nome da sua cidade é $resposta');

  print('informe seu estado:');
  resposta = stdin.readLineSync();
  if (resposta != null) {
    try {
      var estado = jsonDecode(resposta);
    } catch (e) {
      print("");
    }
  } else {
    print('resposta nula');
  }
  print('o nome do seu estado é $resposta');
}
